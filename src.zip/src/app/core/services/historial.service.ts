import { Injectable } from '@angular/core';

export type Materia = 'lectura' | 'matematicas' | 'ciencias';

export interface ResultadoEjercicio {
  materia: Materia;

  // id del recurso concreto (ej. el id de un TextoLectura) -- útil el
  // día que queramos evitar repetir el mismo ejercicio dos veces.
  refId: string;
  titulo: string;

  aciertos: number;
  total: number;

  fecha: string; // ISO
}

export interface ResumenMateria {
  numResultados: number;
  porcentajeAciertos: number; // 0-100, redondeado. 0 si no hay resultados.
  ultimoResultado: ResultadoEjercicio | null;
}

const CLAVE_STORAGE = 'ilbe_historial';

/**
 * Igual que PerfilService: guarda solo en localStorage, solo en este
 * dispositivo. El día que haya backend real, este es el servicio que
 * hay que apuntar a él (la interfaz pública -- guardarResultado /
 * obtenerHistorial / obtenerResumen -- no debería tener que cambiar).
 */
@Injectable({
  providedIn: 'root',
})
export class HistorialService {

  guardarResultado(resultado: ResultadoEjercicio): void {
    const historial = this.obtenerHistorial();
    historial.push(resultado);
    localStorage.setItem(CLAVE_STORAGE, JSON.stringify(historial));
  }

  obtenerHistorial(materia?: Materia): ResultadoEjercicio[] {
    const raw = localStorage.getItem(CLAVE_STORAGE);
    const todos: ResultadoEjercicio[] = raw ? JSON.parse(raw) : [];
    return materia ? todos.filter((r) => r.materia === materia) : todos;
  }

  obtenerResumen(materia: Materia): ResumenMateria {
    const resultados = this.obtenerHistorial(materia);

    const totalAciertos = resultados.reduce((acc, r) => acc + r.aciertos, 0);
    const totalPreguntas = resultados.reduce((acc, r) => acc + r.total, 0);

    return {
      numResultados: resultados.length,
      porcentajeAciertos: totalPreguntas > 0 ? Math.round((totalAciertos / totalPreguntas) * 100) : 0,
      ultimoResultado: resultados.length > 0 ? resultados[resultados.length - 1] : null,
    };
  }
}