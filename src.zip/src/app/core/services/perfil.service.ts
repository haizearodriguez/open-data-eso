import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';

import { PerfilAlumno, CursoEso, ModeloLinguistico } from '../../models/perfil.model';
import { CalibracionService } from './calibracion.service';

const CLAVE_STORAGE = 'ilbe_perfil_actual';

// Alfabeto sin 0/O, 1/I/L para evitar confusiones al copiar el código a mano.
const ALFABETO_CODIGO = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

/**
 * -----------------------------------------------------------------------
 * IMPORTANTE — limitación conocida: este servicio guarda el perfil solo
 * en localStorage (solo en ESTE dispositivo). El código de recuperación
 * generado no permite todavía recuperar el perfil desde otro
 * dispositivo -- eso requiere un backend que lo guarde indexado por
 * ese código.
 * -----------------------------------------------------------------------
 */
@Injectable({
  providedIn: 'root'
})
export class PerfilService {

  constructor(private calibracionService: CalibracionService) {}

  /**
   * Crea el perfil calculando primero el sesgo_inicial a partir del
   * municipio del centro (llamada a EUSTAT vía CalibracionService).
   * Por eso devuelve un Observable en vez de un valor síncrono.
   */
  crearPerfil(datos: {
    centroId: string;
    centroNombre: string;
    municipioCodigo: string;
    curso: CursoEso;
    grupo: string;
    modeloLinguistico: ModeloLinguistico;
  }): Observable<PerfilAlumno> {

    return this.calibracionService.calcularSesgoInicial(datos.municipioCodigo).pipe(
      map((resultado) => {

        const perfil: PerfilAlumno = {
          ...datos,
          sesgoInicial: resultado.sesgoInicial,
          codigo: this.generarCodigo(),
          creadoEn: new Date().toISOString(),
        };

        localStorage.setItem(CLAVE_STORAGE, JSON.stringify(perfil));

        return perfil;
      }),
    );
  }

  obtenerPerfilActual(): PerfilAlumno | null {
    const raw = localStorage.getItem(CLAVE_STORAGE);
    return raw ? (JSON.parse(raw) as PerfilAlumno) : null;
  }

  limpiarPerfil(): void {
    localStorage.removeItem(CLAVE_STORAGE);
  }

  private generarCodigo(): string {
    const parte = (longitud: number) =>
      Array.from(
        { length: longitud },
        () => ALFABETO_CODIGO[Math.floor(Math.random() * ALFABETO_CODIGO.length)]
      ).join('');

    return `${parte(3)}-${parte(3)}`;
  }
}