import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import {
  IonContent, IonHeader, IonToolbar, IonTitle, IonItem, IonLabel,
  IonSearchbar, IonList, IonSelect, IonSelectOption, IonButton, IonSpinner
} from '@ionic/angular';

import { CentrosService } from '../../core/services/centros.service';
import { PerfilService } from '../../core/services/perfil.service';
import { CentroEducativo } from '../../models/centro.model';
import { CursoEso, ModeloLinguistico, PerfilAlumno } from '../../models/perfil.model';

type Paso = 'formulario' | 'calculando' | 'bienvenida' | 'codigo';

interface EstadoOnboarding {
  paso: Paso;
  error: string;
  perfilCreado: PerfilAlumno | null;
}

@Component({
  selector: 'app-onboarding',
  templateUrl: 'onboarding.page.html',
  styleUrls: ['onboarding.page.scss'],
  imports: [
    CommonModule, FormsModule,
    IonContent, IonHeader, IonToolbar, IonTitle, IonItem, IonLabel,
    IonSearchbar, IonList, IonSelect, IonSelectOption, IonButton, IonSpinner
  ],
})
export class OnboardingPage {

  private estadoSubject = new BehaviorSubject<EstadoOnboarding>({
    paso: 'formulario',
    error: '',
    perfilCreado: null,
  });
  estado$ = this.estadoSubject.asObservable();

  resultadosCentro: CentroEducativo[] = [];
  centroSeleccionado?: CentroEducativo;

  cursos: { valor: CursoEso; etiqueta: string }[] = [
    { valor: '1', etiqueta: '1º ESO' },
    { valor: '2', etiqueta: '2º ESO' },
    { valor: '3', etiqueta: '3º ESO' },
    { valor: '4', etiqueta: '4º ESO' },
  ];

  grupos = ['A', 'B', 'C', 'D', 'E'];

  modelos: ModeloLinguistico[] = ['A', 'B', 'D'];

  curso?: CursoEso;
  grupo?: string;
  modeloLinguistico?: ModeloLinguistico;

  constructor(
    private centrosService: CentrosService,
    private perfilService: PerfilService,
    private router: Router,
  ) {
    this.centrosService.getCentros().subscribe({
      error: (error) => console.error('Error cargando centros:', error),
    });
  }

  get formularioValido(): boolean {
    return !!(
      this.centroSeleccionado &&
      this.curso &&
      this.grupo &&
      this.modeloLinguistico
    );
  }

  buscarCentro(event: any): void {
    const texto = event.target.value || '';

    if (texto.length < 3) {
      this.resultadosCentro = [];
      return;
    }

    this.resultadosCentro = this.centrosService.buscarCentros(texto).slice(0, 20);
  }

  seleccionarCentro(centro: CentroEducativo): void {
    this.centroSeleccionado = centro;
    this.resultadosCentro = [];
  }

  seleccionarModelo(modelo: ModeloLinguistico): void {
    this.modeloLinguistico = modelo;
  }

  crearPerfil(): void {
    if (
      !this.formularioValido ||
      !this.centroSeleccionado ||
      !this.curso ||
      !this.grupo ||
      !this.modeloLinguistico
    ) {
      return;
    }

    this.estadoSubject.next({ paso: 'calculando', error: '', perfilCreado: null });

    this.perfilService.crearPerfil({
      centroId: this.centroSeleccionado.id,
      centroNombre: this.centroSeleccionado.nombre,
      municipioCodigo: this.centroSeleccionado.municipioCodigo,
      curso: this.curso,
      grupo: this.grupo,
      modeloLinguistico: this.modeloLinguistico,
    }).subscribe({

      next: (perfil) => {
        this.estadoSubject.next({ paso: 'bienvenida', error: '', perfilCreado: perfil });
      },

      error: (error) => {
        console.error('Error creando el perfil (calibración EUSTAT):', error);
        this.estadoSubject.next({
          paso: 'formulario',
          error: 'No se ha podido calcular tu perfil. Inténtalo de nuevo.',
          perfilCreado: null,
        });
      },
    });
  }

  empezar(): void {
    const actual = this.estadoSubject.value;
    this.estadoSubject.next({ ...actual, paso: 'codigo' });
  }

  continuar(): void {
    this.router.navigateByUrl('/home');
  }
}