import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { BehaviorSubject, switchMap, map, throwError } from 'rxjs';
import {
  IonContent, IonHeader, IonToolbar, IonTitle, IonButton, IonSpinner,
  IonRadioGroup, IonRadio, IonItem, IonLabel, IonList,
} from '@ionic/angular';

import { TextosService } from '../../core/services/textos.service';
import { PerfilService } from '../../core/services/perfil.service';
import { HistorialService } from '../../core/services/historial.service';
import { elegirTextoInicial } from '../../core/utils/seleccion-texto';
import { TextoLectura, PreguntaComprension } from '../../models/texto-lectura.model';
import { PerfilAlumno } from '../../models/perfil.model';

const NUM_PREGUNTAS = 4;

type PasoLectura = 'sin-perfil' | 'cargando' | 'leyendo' | 'respondiendo' | 'corregido' | 'error';

interface EstadoLectura {
  paso: PasoLectura;
  error: string;
  texto: TextoLectura | null;
  preguntas: PreguntaComprension[];
  respuestas: (number | null)[];
  aciertos: number;
}

function estadoInicial(paso: PasoLectura = 'cargando'): EstadoLectura {
  return { paso, error: '', texto: null, preguntas: [], respuestas: [], aciertos: 0 };
}

@Component({
  selector: 'app-lectura',
  templateUrl: './lectura.page.html',
  styleUrls: ['./lectura.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent, IonHeader, IonToolbar, IonTitle, IonButton, IonSpinner,
    IonRadioGroup, IonRadio, IonItem, IonLabel, IonList,
  ],
})
export class LecturaPage {

  private estadoSubject = new BehaviorSubject<EstadoLectura>(estadoInicial());
  estado$ = this.estadoSubject.asObservable();

  private perfil: PerfilAlumno | null;

  constructor(
    private textosService: TextosService,
    private perfilService: PerfilService,
    private historialService: HistorialService,
    private router: Router,
  ) {
    this.perfil = this.perfilService.obtenerPerfilActual();

    if (!this.perfil) {
      this.estadoSubject.next(estadoInicial('sin-perfil'));
      return;
    }

    this.cargarLectura();
  }

  private cargarLectura(): void {
    const perfil = this.perfil;
    if (!perfil) {
      return;
    }

    this.estadoSubject.next(estadoInicial('cargando'));

    this.textosService.getTextos().pipe(
      map((textos) => elegirTextoInicial(textos, perfil)),
      switchMap((texto) => {
        if (!texto) {
          return throwError(() => new Error('No hay textos disponibles todavía para tu perfil.'));
        }

        console.log('Texto elegido:', texto.id, texto.titulo); // <-- temporal

        return this.textosService.generarPreguntas(texto, NUM_PREGUNTAS).pipe(
          map((preguntas) => ({ texto, preguntas })),
        );
      }),
    ).subscribe({
      next: ({ texto, preguntas }) => {
        this.estadoSubject.next({
          paso: 'leyendo',
          error: '',
          texto,
          preguntas,
          respuestas: new Array(preguntas.length).fill(null),
          aciertos: 0,
        });
      },
      error: (error) => {
        console.error('Error cargando la lectura:', error);
        this.estadoSubject.next({
          ...estadoInicial('error'),
          error: error?.message ?? 'No se ha podido cargar el ejercicio. Inténtalo de nuevo.',
        });
      },
    });
  }

  empezarPreguntas(): void {
    const actual = this.estadoSubject.value;
    if (actual.paso !== 'leyendo') {
      return;
    }

    this.estadoSubject.next({ ...actual, paso: 'respondiendo' });
  }

  seleccionarRespuesta(indicePregunta: number, indiceOpcion: number): void {
    const actual = this.estadoSubject.value;
    if (actual.paso !== 'respondiendo') {
      return;
    }

    const respuestas = [...actual.respuestas];
    respuestas[indicePregunta] = indiceOpcion;

    this.estadoSubject.next({ ...actual, respuestas });
  }

  todasContestadas(estado: EstadoLectura): boolean {
    return estado.respuestas.length > 0 && estado.respuestas.every((r) => r !== null);
  }

  corregir(): void {
    const actual = this.estadoSubject.value;
    if (actual.paso !== 'respondiendo' || !this.todasContestadas(actual) || !actual.texto) {
      return;
    }

    const aciertos = actual.preguntas.reduce(
      (acc, pregunta, i) => acc + (actual.respuestas[i] === pregunta.respuestaCorrecta ? 1 : 0),
      0,
    );

    try {
      this.historialService.guardarResultado({
        materia: 'lectura',
        refId: actual.texto.id,
        titulo: actual.texto.titulo,
        aciertos,
        total: actual.preguntas.length,
        fecha: new Date().toISOString(),
      });
    } catch (error) {
      console.error('No se ha podido guardar el resultado en el historial:', error);
    }

    this.estadoSubject.next({ ...actual, paso: 'corregido', aciertos });
  }

  otroTexto(): void {
    this.cargarLectura();
  }

  reintentar(): void {
    this.cargarLectura();
  }

  irAlOnboarding(): void {
    this.router.navigateByUrl('/onboarding');
  }

  irAHome(): void {
    this.router.navigateByUrl('/home');
  }
}